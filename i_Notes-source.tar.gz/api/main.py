# Load environment variables
from dotenv import load_dotenv

load_dotenv()

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from loguru import logger
from starlette.exceptions import HTTPException as StarletteHTTPException

from api.auth import JWTAuthMiddleware
from open_notebook.exceptions import (
    AuthenticationError,
    ConfigurationError,
    ExternalServiceError,
    InvalidInputError,
    NetworkError,
    NotFoundError,
    OpenNotebookError,
    RateLimitError,
)
from api.routers import (
    auth,
    chat,
    config,
    context,
    credentials,
    embedding,
    embedding_rebuild,
    episode_profiles,
    insights,
    languages,
    models,
    notebooks,
    notes,
    podcasts,
    search,
    settings,
    source_chat,
    sources,
    speaker_profiles,
    transformations,
)
from api.routers import commands as commands_router
from api.routers import mindmap as mindmap_router
from api.routers import infographic as infographic_router
from api.routers import otp as otp_router
from api.routers import users as users_router
from api.routers import bank_analysis as bank_analysis_router
from api.routers import mobile_data_analysis as mobile_data_analysis_router
from open_notebook.database.async_migrate import AsyncMigrationManager
from open_notebook.utils.encryption import get_secret_from_env

# Import commands to register them in the API process
try:
    logger.info("Commands imported in API process")
except Exception as e:
    logger.error(f"Failed to import commands in API process: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan event handler for the FastAPI application.
    Runs database migrations automatically on startup.
    """
    import os

    # Startup: Security checks
    logger.info("Starting API initialization...")

    # Security check: Encryption key
    if not get_secret_from_env("OPEN_NOTEBOOK_ENCRYPTION_KEY"):
        logger.warning(
            "OPEN_NOTEBOOK_ENCRYPTION_KEY not set. "
            "API key encryption will fail until this is configured. "
            "Set OPEN_NOTEBOOK_ENCRYPTION_KEY to any secret string."
        )

    # Run database migrations

    try:
        migration_manager = AsyncMigrationManager()
        current_version = await migration_manager.get_current_version()
        logger.info(f"Current database version: {current_version}")

        if await migration_manager.needs_migration():
            logger.warning("Database migrations are pending. Running migrations...")
            await migration_manager.run_migration_up()
            new_version = await migration_manager.get_current_version()
            logger.success(
                f"Migrations completed successfully. Database is now at version {new_version}"
            )
        else:
            logger.info(
                "Database is already at the latest version. No migrations needed."
            )
    except Exception as e:
        logger.error(f"CRITICAL: Database migration failed: {str(e)}")
        logger.exception(e)
        # Fail fast - don't start the API with an outdated database schema
        raise RuntimeError(f"Failed to run database migrations: {str(e)}") from e

    # Run podcast profile data migration (legacy strings -> Model registry)
    try:
        from open_notebook.podcasts.migration import migrate_podcast_profiles

        await migrate_podcast_profiles()
    except Exception as e:
        logger.warning(f"Podcast profile migration encountered errors: {e}")
        # Non-fatal: profiles can be migrated manually via UI

    logger.success("API initialization completed successfully")

    # Fix stuck 'running' commands from previous worker sessions.
    # When the worker crashes or restarts, commands stay in 'running' state
    # and get re-executed on next startup — causing duplicate insights.
    try:
        from open_notebook.database.repository import repo_query as _rq, ensure_record_id as _eid
        stuck = await _rq(
            "SELECT id, result FROM command WHERE status = 'running'"
        )
        fixed_count = 0
        for cmd in (stuck or []):
            res = cmd.get("result") or {}
            if res.get("execution_time") is not None and res.get("success") is True:
                await _rq(
                    "UPDATE $rid SET status = 'completed'",
                    {"rid": _eid(str(cmd["id"]))},
                )
                fixed_count += 1
        if fixed_count:
            logger.info(f"Fixed {fixed_count} stuck 'running' command(s) from previous session")
    except Exception as e:
        logger.warning(f"Could not fix stuck commands: {e}")

    # Start Kafka mind map consumer as a background task
    kafka_consumer_task = None
    try:
        from api.routers.mindmap import start_kafka_consumer
        kafka_consumer_task = asyncio.create_task(start_kafka_consumer())
        logger.info("Kafka mind map consumer task started")
    except Exception as e:
        logger.warning(f"Could not start Kafka consumer task: {e}")

    # Start Kafka infographic consumer as a background task
    kafka_infographic_task = None
    try:
        from api.routers.infographic import start_kafka_consumer as start_infographic_consumer
        kafka_infographic_task = asyncio.create_task(start_infographic_consumer())
        logger.info("Kafka infographic consumer task started")
    except Exception as e:
        logger.warning(f"Could not start Kafka infographic consumer task: {e}")

    # Yield control to the application
    yield

    # Shutdown: cancel Kafka consumers
    for task in [kafka_consumer_task, kafka_infographic_task]:
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
    logger.info("API shutdown complete")


app = FastAPI(
    title="Open Notebook API",
    description="API for Open Notebook - Research Assistant",
    lifespan=lifespan,
)

# Add JWT authentication middleware first.
# Public paths listed below bypass token validation entirely.
app.add_middleware(
    JWTAuthMiddleware,
    excluded_paths=[
        "/",
        "/health",
        "/docs",
        "/openapi.json",
        "/redoc",
        "/api/auth/status",
        "/api/auth/login",
        "/api/config",
        "/api/otp/send",
        "/api/otp/verify",
        "/api/otp/clear",
        "/api/users/reset-password",
        "/api/users/register",
        "/api/users/login",
    ],
)

# Add CORS middleware last (so it processes first)
# Only allow requests from the frontend (port 3000) and the API itself (port 5055)
# on the known host IP. All other origins are blocked.
ALLOWED_ORIGINS = [
    "http://100.73.235.251:5055",
    "http://100.73.235.251:8502",
    "http://100.73.235.251:3000",
    "http://100.73.235.251:8080",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "*"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _resolve_cors_origin(request: Request) -> str:
    """
    Return the request origin only when it is in ALLOWED_ORIGINS.
    Falls back to the first allowed origin so the header is always valid
    (browsers will block the response anyway if the origin doesn't match).
    """
    origin = request.headers.get("origin", "")
    if origin in ALLOWED_ORIGINS:
        return origin
    # Fallback — never echo back an arbitrary origin
    return ALLOWED_ORIGINS[0]


# Custom exception handler to ensure CORS headers are included in error responses.
# This is particularly important for 413 (Payload Too Large) errors during file uploads.
# Note: If a reverse proxy (nginx, traefik) returns 413 before the request reaches
# FastAPI, this handler won't be called. Configure your reverse proxy to add CORS
# headers to error responses in that case.
@app.exception_handler(StarletteHTTPException)
async def custom_http_exception_handler(request: Request, exc: StarletteHTTPException):
    origin = _resolve_cors_origin(request)
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
        headers={
            **(exc.headers or {}),
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Credentials": "true",
            "Access-Control-Allow-Methods": "*",
            "Access-Control-Allow-Headers": "*",
        },
    )


def _cors_headers(request: Request) -> dict[str, str]:
    origin = _resolve_cors_origin(request)
    return {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Credentials": "true",
        "Access-Control-Allow-Methods": "*",
        "Access-Control-Allow-Headers": "*",
    }


@app.exception_handler(NotFoundError)
async def not_found_error_handler(request: Request, exc: NotFoundError):
    return JSONResponse(
        status_code=404,
        content={"detail": str(exc)},
        headers=_cors_headers(request),
    )


@app.exception_handler(InvalidInputError)
async def invalid_input_error_handler(request: Request, exc: InvalidInputError):
    return JSONResponse(
        status_code=400,
        content={"detail": str(exc)},
        headers=_cors_headers(request),
    )


@app.exception_handler(AuthenticationError)
async def authentication_error_handler(request: Request, exc: AuthenticationError):
    return JSONResponse(
        status_code=401,
        content={"detail": str(exc)},
        headers=_cors_headers(request),
    )


@app.exception_handler(RateLimitError)
async def rate_limit_error_handler(request: Request, exc: RateLimitError):
    return JSONResponse(
        status_code=429,
        content={"detail": str(exc)},
        headers=_cors_headers(request),
    )


@app.exception_handler(ConfigurationError)
async def configuration_error_handler(request: Request, exc: ConfigurationError):
    return JSONResponse(
        status_code=422,
        content={"detail": str(exc)},
        headers=_cors_headers(request),
    )


@app.exception_handler(NetworkError)
async def network_error_handler(request: Request, exc: NetworkError):
    return JSONResponse(
        status_code=502,
        content={"detail": str(exc)},
        headers=_cors_headers(request),
    )


@app.exception_handler(ExternalServiceError)
async def external_service_error_handler(request: Request, exc: ExternalServiceError):
    return JSONResponse(
        status_code=502,
        content={"detail": str(exc)},
        headers=_cors_headers(request),
    )


@app.exception_handler(OpenNotebookError)
async def open_notebook_error_handler(request: Request, exc: OpenNotebookError):
    return JSONResponse(
        status_code=500,
        content={"detail": str(exc)},
        headers=_cors_headers(request),
    )


# Include routers
app.include_router(auth.router, prefix="/api", tags=["auth"])
app.include_router(config.router, prefix="/api", tags=["config"])
app.include_router(notebooks.router, prefix="/api", tags=["notebooks"])
app.include_router(search.router, prefix="/api", tags=["search"])
app.include_router(models.router, prefix="/api", tags=["models"])
app.include_router(transformations.router, prefix="/api", tags=["transformations"])
app.include_router(notes.router, prefix="/api", tags=["notes"])
app.include_router(embedding.router, prefix="/api", tags=["embedding"])
app.include_router(
    embedding_rebuild.router, prefix="/api/embeddings", tags=["embeddings"]
)
app.include_router(settings.router, prefix="/api", tags=["settings"])
app.include_router(context.router, prefix="/api", tags=["context"])
app.include_router(sources.router, prefix="/api", tags=["sources"])
app.include_router(insights.router, prefix="/api", tags=["insights"])
app.include_router(commands_router.router, prefix="/api", tags=["commands"])
app.include_router(podcasts.router, prefix="/api", tags=["podcasts"])
app.include_router(episode_profiles.router, prefix="/api", tags=["episode-profiles"])
app.include_router(speaker_profiles.router, prefix="/api", tags=["speaker-profiles"])
app.include_router(chat.router, prefix="/api", tags=["chat"])
app.include_router(source_chat.router, prefix="/api", tags=["source-chat"])
app.include_router(credentials.router, prefix="/api", tags=["credentials"])
app.include_router(languages.router, prefix="/api", tags=["languages"])
app.include_router(mindmap_router.router, prefix="/api", tags=["mindmap"])
app.include_router(infographic_router.router, prefix="/api", tags=["infographic"])
app.include_router(otp_router.router, prefix="/api", tags=["otp"])
app.include_router(users_router.router, prefix="/api", tags=["users"])
app.include_router(bank_analysis_router.router, prefix="/api", tags=["bank-analysis"])
app.include_router(mobile_data_analysis_router.router, prefix="/api", tags=["mobile-analysis"])


@app.get("/")
async def root():
    return {"message": "Open Notebook API is running"}


@app.get("/health")
async def health():
    return {"status": "healthy"}
